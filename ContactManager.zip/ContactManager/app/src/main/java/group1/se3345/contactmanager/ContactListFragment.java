package group1.se3345.contactmanager;

import android.app.Activity;
import android.app.ListFragment;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

/**
 * Created by Sharad on 11/6/15.
 */
public class ContactListFragment extends ListFragment {

    public interface ContactListFragmentListener
    {
        public void onContactSelected(long rowID);

        public void onAddContact();
    }

    private ContactListFragmentListener listener;

    private ListView contactListView;
    private CursorAdapter contactAdapter;

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
        listener = (ContactListFragmentListener) activity;
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
        listener = null;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);
        setRetainInstance(true);
        setHasOptionsMenu(true);

        setEmptyText(getResources().getString(R.string.no_contacts));

        contactListView = getListView();
        contactListView.setOnItemClickListener(viewContactListener);
        contactListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        //map
        String[] from = new String[]{"name"};
        int[] to = new int[]{android.R.id.text1};
        contactAdapter = new SimpleCursorAdapter(getActivity(),
                android.R.layout.simple_list_item_1, null, from, to, 0);
        setListAdapter(contactAdapter);
    }

    AdapterView.OnItemClickListener viewContactListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            listener.onContactSelected(id);
        }
    };
}
